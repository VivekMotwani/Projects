# FOML-PROJECT-CANTEEN-EMPTY-TABLE > 2023-11-01 1:19am
https://universe.roboflow.com/fomlproject/foml-project-canteen-empty-table

Provided by a Roboflow user
License: CC BY 4.0

